# Handoff: Mario redesign — desktop, web and mobile

## Overview

Mario is a Flutter block-notes app (notebooks → sections → pages) with a rich AppFlowy-based
editor, custom blocks for code / math / drawing / spreadsheet / image / table / audio, an AI
panel, Drive sync and PDF + Markdown export. It ships today on Linux desktop and web; iOS and
Android exist only as project scaffolding.

This redesign covers all three platforms with one layout language. It targets eight specific
problems in the current build:

| Problem today | What the redesign does |
|---|---|
| Three levels of nesting to reach a page | The 60px notebook rail is deleted. One 284px sidebar: notebook switcher pill → sections → pages. Pinned pages sit above the tree; ⌘K reaches anything. |
| Actions hidden in right-click menus | Every row carries a visible `…` on hover; create actions are visible pills (`New page`, `Add` section). Right-click still works as a shortcut, never as the only route. |
| Block types hard to discover | The 40-icon ribbon is replaced by a labelled **Insert** tray — pill chips with icon + word, opened from the format bar, the `+` gutter button, or `/`. |
| AI feels bolted on | The tabbed side panel becomes (a) an always-present **Ask composer** at the foot of the page, and (b) a 400px dock with one segmented control (Ask / Quiz / Writing) instead of three tab chips. |
| Toolbar icons unlabelled | Format bar groups carry words (`Body text`, `Lists`, `Insert`); only B / I / U / highlight stay glyph-only. |
| Too dense / cramped | 40px sidebar rows, 44px minimum touch targets, 28px container radii, 16px body text. |
| No mobile | Full editor parity on 390 × 844 — home, notebook, editor, insert sheet, AI sheet, search — with a five-slot tab bar and a centre FAB. |
| Empty states don't teach | Each empty state offers the next action: create a notebook, blank page / dictate / photograph, or a "try one" block row. |

## About the design files

The files in this bundle are **design references created in HTML** — prototypes showing the
intended look and behaviour, not production code to copy. The task is to **recreate these
designs in Mario's existing Flutter environment**, using its established patterns: `ThemeData`
factories in `lib/ui/theme.dart`, a token class in `lib/ui/colors.dart`, Riverpod providers,
`go_router` routes, and the existing widget structure under `lib/features/`. Do not port the
HTML.

Two HTML files are included:

- `Mario Today.dc.html` — a faithful recreation of the **current** UI, rebuilt from the Dart
  source. Use it as the before-state and as a check that nothing was dropped.
- `Mario Redesign.dc.html` — the **new** design. Screens are labelled `2a` … `2k`.

Both open directly in a browser.

## Fidelity

**High-fidelity.** Final colours, typography, spacing and radii. Recreate pixel-perfectly using
Flutter's own widgets — the values below are exact.

---

## Design tokens

The redesign keeps the **Organic** structure — roles, 100–900 ramps, radii, type — with the
palette retuned to the Mario mark. Replace `MarioColors` in `lib/ui/colors.dart` with these.

### The mark

`assets/mario_mark.png` (1024 × 1024) is the source of the whole palette. Four colours:

| | Hex | Where it comes from |
|---|---|---|
| Navy | `#17233d` | The frame and the moustache — this is the ink |
| Cream | `#fff8e8` | The page — this is the ground |
| Gold | `#f2c14e` | The left stripe — second accent |
| Coral | `#f05a47` | The centre stripe — primary accent |

The mark is used as-is for the app mark at 38px (radius 13) in the top bar, 64px (radius 22) on
sign-in and 24px (radius 9) in the theme previews. Do not redraw it and do not recolour it.

### Colour — light

| Role | Hex | Used for |
|---|---|---|
| `bg` | `#fff8e8` | App background, editor pane |
| `surface` | `#f7ecd4` | Sidebar, notebook cards, bottom sheets |
| `text` | `#17233d` | Primary text |
| `accent` | `#f05a47` | Primary buttons, active states |
| `accent-2` | `#f2c14e` | Second voice — saved dot, avatars, equation tints |
| `divider` | `rgba(23,35,61,0.16)` | Hairlines |

### Tonal ramps

Neutral (cream → navy): `100 #fffcf3` · `200 #fff3dd` · `300 #eee2c8` · `400 #cdc4b1` ·
`500 #a6a396` · `600 #7d7f7d` · `700 #565d64` · `800 #333e51` · `900 #17233d`

Accent (coral): `100 #fff0ec` · `200 #ffdcd4` · `300 #ffbeb1` · `400 #fb8d79` · `500 #f05a47` ·
`600 #d13d2c` · `700 #a72c1e` · `800 #7b1f15` · `900 #4f150f`

Accent-2 (gold): `100 #fff8e0` · `200 #fdeebd` · `300 #f8dd8f` · `400 #f2c14e` · `500 #dda72f` ·
`600 #b98620` · `700 #8f6717` · `800 #664912` · `900 #412e0d`

Use 100–300 for tinted fills and hovers, 500 as the role's base, 700–900 for text on tinted
fills and pressed states. Coral at paragraph size needs `accent-700`, not `accent`.

### The four themes

`MarioThemeMode` becomes `{ light, white, calmNight, black, system }`. `system` resolves to
Light by day and Calm night after dark. Screen `2l` shows all four at once.

| | Light | White | Calm night | Black |
|---|---|---|---|---|
| Ground | `#fff8e8` | `neutral-100` 40% over `#fff` | `#17233d` | `#000000` |
| Top bar glass | `neutral-100` 72% | `#fff` 72% | `rgba(255,255,255,0.05)` | `rgba(255,255,255,0.05)` |
| Sidebar glass | `surface` 62% | `neutral-100` 70% | `rgba(255,255,255,0.045)` | `rgba(255,255,255,0.055)` |
| Hairline | `neutral-100` 60% | `neutral-200` | `rgba(255,255,255,0.09)` | `rgba(255,255,255,0.10)` |
| Paper | `#fffcf3` solid | `#ffffff` solid, `neutral-200` border | `#333e51` solid | `rgba(255,255,255,0.05)` glass |
| Text | `#17233d` | `#17233d` | `#fffcf3` | `#fffcf3` |
| Muted | `neutral-700` | `neutral-600` | `neutral-400` | `neutral-400` |
| Accent | `#f05a47` | `#f05a47` | `#fb8d79` | `#fb8d79` |
| Second accent | `#f2c14e` | `#f2c14e` | `#f2c14e` | `#f2c14e` |
| Selected page row | `accent-300` 62% | `accent-200` | `accent-400` 20% | `accent-400` 22% |
| Elevation | `shadow-sm/md` | `shadow-sm` + borders | `shadow` on paper only | none — alpha is the elevation |

Calm night is the mark's own navy used full-bleed. Light and White share one ink set; Calm night and Black share the other. The only structural
difference between the two darks is the ground and whether the paper is solid: Calm night keeps
a solid `#333e51` sheet so long reading sessions have a settled surface, Black lets the
paper be glass so the OLED stays off behind it.

### Colour — dark (Black)

Derived from the same ramps; no new hues.

| Role | Value |
|---|---|
| App background | **`#000`** pure black |
| Sidebar | `rgba(255,255,255,0.055)` glass over black |
| Paper / cards | `rgba(255,255,255,0.05)` glass |
| Primary text | `neutral-100 #f9f4ed` |
| Secondary text | `neutral-400 #c0b6a5` |
| Accent | `accent-400 #f6a06b` (one step lighter than the light-theme accent, per the ramp rule for dark grounds) |
| Accent-2 | `accent-2-400 #aebf92` |
| Dividers | `rgba(255,255,255,0.10)` |
| Fills / inputs | `rgba(255,255,255,0.08)`; borders `rgba(255,255,255,0.13)` |

The **Book** sepia theme is retired — the light theme is already warm paper. If you want to keep
it, treat it as light with `bg #f7efdf`.

### Notebook / section label palette

Six distinguishable colours, all drawn from the two ramps so notebook strips never fight the
chrome:

| Fill | Ramp step | Initial ink |
|---|---|---|
| `#fb8d79` apricot | accent-400 | navy `#17233d` |
| `#f05a47` coral | accent-500 | cream `#fffcf3` |
| `#a72c1e` deep coral | accent-700 | cream `#fffcf3` |
| `#f2c14e` gold | accent-2-400 | navy `#17233d` |
| `#b98620` bronze | accent-2-600 | cream `#fffcf3` |
| `#8f6717` deep gold | accent-2-700 | cream `#fffcf3` |

**Ink rule for every tinted fill:** navy on the 300 and 400 steps, cream on 500 and darker.
Cream on gold or apricot lands near 2:1 and disappears — this is the one contrast trap in the
new palette. The mark itself follows the rule: the moustache is navy on cream and on gold.

The one deliberate 3:1 call is `.btn-primary` — cream on coral `#f05a47` at 3.17:1 for a 14px
Caprasimo label. That clears the system's 3:1 bar for interface chrome but has no headroom;
if you want more, drop the fill to `accent-600 #d13d2c` (5.3:1) and keep coral for the hover.

### Typography

| Token | Value |
|---|---|
| Display / headings | **Caprasimo**, weight 400 only |
| Body / UI | **Figtree**, weights 400 / 600 / 700 |

Both are Google Fonts — swap `GoogleFonts.spaceGrotesk` → `GoogleFonts.caprasimo` and
`GoogleFonts.inter` → `GoogleFonts.figtree` throughout. Caprasimo has one weight; never request
600/700 from it.

Scale as used:

| Element | Font | Size / line-height / weight |
|---|---|---|
| Page title | Caprasimo | 38 / 1.08 / 400 |
| Home greeting | Caprasimo | 42 / 1.05 / 400 |
| Section heading in page | Caprasimo | 23 / 1.2 / 400 |
| Dialog title | Caprasimo | 22 / 1.2 / 400 |
| Notebook switcher | Caprasimo | 17 / 1.2 / 400 |
| Button label | Caprasimo | 14–15 / 1.2 / 400 |
| Body copy | Figtree | 16 / 1.65 / 400 |
| Sidebar page row | Figtree | 14 / 1 / 400 (700 when selected) |
| Section header | Figtree | 14 / 1 / 700 |
| Group label (`PINNED`, `SECTIONS`) | Figtree | 11 / 1 / 700, letter-spacing 0.12em, uppercase |
| Meta / timestamp | Figtree | 13 / 1 / 400 |
| Tag / chip | Figtree | 11–13 / 1 / 600 |

### Spacing, radius, elevation

Spacing scale: `4.4 · 8.8 · 13.2 · 17.6 · 26.4 · 35.2` px (Organic's 1.10× density scale).

| Radius | Value | Applied to |
|---|---|---|
| `sm` | 8px | Small inline chips |
| `md` | 16px | Rows, cards, sheets, tray |
| `lg` | 28px | Paper card, app frame, panels |
| pill | 999px | Every button, input, tag, segmented control, avatar |
| dialog | 32px | Modal surfaces |

| Shadow | Value |
|---|---|
| `sm` | `0 1px 2px rgba(23,35,61,0.16)` |
| `md` | `0 3px 10px rgba(23,35,61,0.18)` |
| `lg` | `0 12px 32px rgba(23,35,61,0.24)` |

Dark theme: replace `lg` with `0 12px 32px rgba(0,0,0,0.35)`.

### Icons

**Lucide**, stroke-width **2.75**. Sizes: 15–17px in the sidebar and format bar, 18–22px on
mobile, 22px in tab bars, 40px in empty-state medallions. In Flutter use `lucide_icons` (or an
SVG set) — do not fall back to Material Icons, whose 2.0 stroke reads thin and cold against
this palette.

The sidebar carries **no icons at all** on section headers or page rows. Sections are marked by
a 4 × 18 vertical colour strip (5 × 20 on mobile), radius 999; an open section extends that
colour into a 2px vertical rail (3px on mobile) running down the left of its pages at
`accent-300` / 45% on dark. Page rows are plain text against the rail. Page counts sit in a
soft pill: Figtree 11/600 `neutral-700` on `neutral-200`, radius 999, padding 4 8.

### Glass

The chrome is translucent over a tinted ground, Apple-style.

- **Ground**: flat. No gradients, blobs or colour wash sit behind the glass. Light is
  `bg #f5ead8`; **dark is pure black `#000`** — not `neutral-900`.
- **Glass recipe**: `backdrop-filter: blur(26px) saturate(1.7)` with a translucent fill and a
  light hairline. Light — fill `neutral-100` at 62–72%, border `neutral-100` at 60–90%, plus
  `inset 0 1px 0 rgba(255,255,255,0.7)` on floating pills. Dark — fill
  `rgba(255,255,255,0.05)` for the top bar, `0.055` for the sidebar, `0.07–0.08` for pills,
  inputs and the format bar; hairlines `rgba(255,255,255,0.10–0.14)`. No shadows on the dark
  glass — the alpha step off pure black is the elevation.
- **Applied to**: top bar, sidebar, search pill, notebook switcher, format bar, Ask composer,
  the selected page row (`accent-300` at 62%), the mobile tab bar, the mobile insert sheet and
  the mobile editor toolbar.
- **The writing paper**: solid `neutral-100` on light so body copy keeps full contrast; on dark
  it is glass too — `rgba(255,255,255,0.05)` with a `0.11` hairline — with the code block on
  `rgba(0,0,0,0.45)` inside it.

In Flutter, reach for `BackdropFilter(filter: ImageFilter.blur(sigmaX: 13, sigmaY: 13))` inside
a `ClipRRect` — Flutter's sigma is roughly half the CSS blur radius.

### Interaction states

- Hover: accent tint (`accent-100` fills) or `text` at 7%.
- Pressed: one ramp step past the base — `accent-600` on light, `accent-400` on dark.
- Keyboard focus: `2px solid var(--color-accent)`, offset 2px. Never the platform default.
- Disabled: 45% opacity.
- Selection: accent at 30%.

---

## Screens

Screen ids match the badges in `Mario Redesign.dc.html`.

### 2a — Editor shell (desktop & web, 1440 × 900)

Desktop and web are **identical**; the only difference is the desktop window-close control in
the top bar, which the web build omits.

**Top bar — 68px, `bg`, 1px bottom divider, padding 0 20px**
- Left: 38 × 38 mark, radius 13, fill `accent`, `shadow-sm`, letter "M" in Caprasimo 21 on `bg`;
  12px gap; wordmark "Mario" Caprasimo 21.
- Centre: search pill 460 × 42, radius 999, fill `neutral-100`, 1px `neutral-300`, padding
  0 8 0 16. Contains: `search` icon 17px `neutral-600`; placeholder "Search notes, notebooks,
  anything" Figtree 14 `neutral-600`; a `⌘K` badge — Figtree 11/600 `neutral-700`, fill
  `neutral-200`, 1px `neutral-300`, radius 999, padding 5 9.
- Right, 10px gap: `Share` secondary pill (h40, 1px divider border, `share-2` 16px);
  `Ask Mario` primary pill (h40, fill `accent`, text `bg`, `sparkles` 16px); avatar 38 circle
  fill `accent-2-500`, initials Caprasimo 15 on `bg`.

**Sidebar — 284px, fill `surface`, padding 16 14 14**
1. Notebook switcher: full-width row, fill `neutral-100`, radius 16, `shadow-sm`, padding 11 12;
   13px colour dot, name Caprasimo 17, `chevrons-up-down` 16px `neutral-600`. Tapping opens the
   notebook list — this is the whole replacement for the old 60px rail.
2. `New page` primary pill, full width, h42, 12px above.
3. `PINNED` group label, then 38px rows: `star` 15px `accent-500` + label Figtree 14/600.
4. `SECTIONS` group label with an `Add` chip on the right — Figtree 12/600 `accent-700`, fill
   `accent` at 12%, radius 999, padding 5 9, `folder-plus` 13px.
5. Section header row, 36px: chevron 15px, 9px colour dot, name Figtree 14/700, page count
   Figtree 11/600 `neutral-600`.
6. Page rows, 40px, radius 16, indented 10px: `file-text` 15px + label Figtree 14.
   **Selected** — fill `accent-200`, icon `accent-700`, label Figtree 14/700 `accent-800`, and a
   26px circular `…` button (fill `accent-800` at 12%) pinned right.
7. Footer above a 1px top divider: `Trash` and `Settings`, 38px rows, `neutral-600` icons.

**Main pane**
- Header, padding 26 44 0. Breadcrumb: `Physics` tag (`accent-2-100` fill / `accent-2-800`
  text) → `chevron-right` 14px → `Mechanics` tag (`neutral-100` / `neutral-800`); tags are
  Figtree 11, padding 3 10, radius 999. Title Caprasimo 38. Save line: 8px `accent-2-500` dot +
  "All changes saved · edited 4 minutes ago" Figtree 13 `neutral-700`.
- Header actions, right: `Export`, `Draw` secondary pills (h38) and a 38px circular `…`.
- Format bar — an inline-flex pill, fill `neutral-100`, 1px `neutral-300`, radius 999,
  padding 6 8, `shadow-sm`. Order: `Body text ▾` (32px pill, fill `neutral-200`) | divider |
  B / I / U / highlight (32px circles; active = fill `accent-200`, icon `accent-800`) | divider |
  `Lists ▾` | divider | **`Insert`** (32px pill, fill `accent`, text `bg`).
- Paper — max-width 780, fill `neutral-100`, radius 28, `shadow-md`, padding 40 52, 18px gap.
  Body copy Figtree 16/1.65. Equation blocks: fill `accent-2-100`, radius 16, padding 20, serif
  italic 24 in `accent-2-800`. Bullets: 7px `accent-2-500` circles, 12px gap.
- **Insert tray** (open state) — 1.5px dashed `accent-300`, radius 16, padding 16 18, fill
  `accent-100` at 60%. Label `INSERT A BLOCK` Figtree 11/700 uppercase `accent-700`. Chips:
  h36, radius 999, fill `neutral-100`, 1px `neutral-300`, icon 15px `accent-600` + label
  Figtree 13/600, 8px gap, wrapping. Nine chips: Heading, To-do, Equation, Code, Table,
  Spreadsheet, Drawing, Image, Audio.
- **Ask composer** — max-width 780, h52, radius 999, fill `neutral-100`, 1.5px `accent-300`,
  `shadow-sm`. `sparkles` 18px `accent`; placeholder "Ask about this page, or type / to
  summarise, quiz, check writing…" Figtree 15 `neutral-600`; a `Dictate` chip (h34, fill
  `neutral-200`); a 36px circular send button, fill `accent`, `arrow-up` 17px `bg`.

### 2b — Editor shell, dark

Identical geometry on a **pure black** ground. Every chrome surface is white-alpha glass; the
paper is glass too. The code block sits on `rgba(0,0,0,0.45)` with keywords in `accent-300`
and identifiers in `accent-2-300`. Accents step up one level for dark — `accent-400` and
`accent-2-400`.

### 2c — Home (1440 × 900)

Replaces the current "Pick a page to start writing" empty pane. Top bar as 2a, no sidebar.

- Greeting Caprasimo 42; sub-line Figtree 16 `neutral-700`.
- Right: `New notebook` secondary + `New page` primary, both h44 pills.
- `JUMP BACK IN` — three cards, `neutral-100`, radius 32, padding 22 24, `shadow-sm`. Each:
  colour dot + `Notebook › Section` Figtree 12/600 `neutral-700`; title Caprasimo 21; one-line
  excerpt Figtree 13; `clock` 13px + relative time Figtree 12 `neutral-600`.
- `NOTEBOOKS` — four cards, `surface`, radius 32, padding 24. Each: 52px circular avatar with
  the notebook colour and its Caprasimo 22 initial, name Caprasimo 20, "N sections · N pages"
  Figtree 13.

### 2d — AI dock (400 × 740, docks right of the editor)

Header: 32px accent circle with `sparkles`, "Mario" Caprasimo 18, `history` and `x` 30px
buttons. Below it a **segmented control** — fill `neutral-200`, radius 999, padding 4; selected
segment `neutral-100` + `shadow-sm` + Figtree 13/700.

- **Context row**: `file-text` 14px `accent-600`, "Reading **Rotational dynamics**", a `Change`
  link `accent-700`. Fill `neutral-100`, radius 16.
- **User turn**: right-aligned, max-width 86%, fill `accent-200`, text `accent-900`, radius
  `20 20 6 20`, padding 12 16, Figtree 14/1.5.
- **Assistant turn**: 28px `accent-2-500` avatar + bubble `neutral-100`, radius `6 20 20 20`.
  Action row: `Insert into page` primary chip (h30, `corner-down-left` 13px), plus 30px circular
  `copy` and `refresh-cw` buttons on `neutral-200`.
- **Suggestion chips**: h34, 1px `neutral-300`, fill `neutral-100`, icons `accent-600` —
  Summarise page, Quiz me, Search the web.
- **Composer**: h48, radius 999, 1.5px `accent-300`, 34px send circle.
- **Quiz tab**: scope segmented (`This page` / `Whole section`), a progress row
  ("Question 2 of 5" + 6px `accent-2-500` bar), the question card on `neutral-100` radius 16,
  options as 13/14px rows radius 16. Correct option: 2px `accent-2-500` border, fill
  `accent-2-100`, filled radio with a `check`. Verdict strip on `accent-2-100` keeps the
  existing honesty rule verbatim in spirit: multiple choice is marked by comparison, essays are
  labelled drafts.
- Footer states the model and where the key lives.

### 2e — Search palette (680 wide, over a 42% `neutral-900` scrim)

Radius 32, fill `neutral-100`. Query row: `search` 20px `accent`, query Figtree 18, `esc` badge.
Grouped results — `PAGES` then `ACTIONS`. Selected row: fill `accent-200`, title Figtree 15/700
`accent-900`, path + snippet Figtree 12 `accent-800` with the matched term highlighted at
`accent` 35%. Footer hints: `↑↓ move`, `↵ open`, `⌘↵ open in split`, and a note that it searches
titles and content.

### 2f — Settings (940 × 620 dialog)

Category rail 248px on `surface`: Appearance, Editor, Voice, AI models, Sync, Account — 42px
rows, selected gets `neutral-100` + `shadow-sm`. Version string at the foot.

Right pane, padding 32 40: section title Caprasimo 26 + one-line description. **Theme** as three
preview cards (miniature of the actual layout), selected card 2px `accent`. Then rows: `Text
size` slider (accent track, 20px accent thumb), `Page width` segmented (Narrow / Medium / Full),
`Reduce motion` switch. Switch: 52 × 30, radius 999, off `neutral-300`, on `accent`, 24px knob.

### 2g — Sign-in (1100 × 700)

52/48 split. Left panel `neutral-900` (the mark's navy) with three soft circles — 420px
`accent-2-400` at 20%, 240px `accent` at 62%, 160px `neutral-100` at 14% — decorative only.
The 64px mark sits above the headline "Your notes, / your world", Caprasimo 46 in
`neutral-100`; supporting line Figtree 16 at 78%.

Right panel `bg`: "Welcome back" Caprasimo 30, two h52 pills — `Continue with Google`
(`neutral-100`, 1px `neutral-300`, `shadow-sm`) and `Use this device only` (outline). Footnote
about keychain storage, Figtree 12.5 `neutral-600`.

### 2h — Share (520 dialog)

Notebook avatar + `Share <Notebook>` Caprasimo 22 + scope line. Invite row: email input pill
(h46, 1px `neutral-400`), role dropdown pill (`neutral-200`), `Invite` primary pill. `PEOPLE
WITH ACCESS` list with 34px avatars, name + email, role on the right. A link-sharing row with
`link` icon and a switch, defaulting off.

### 2i — Export (520 dialog)

Title + page path. Two format cards side by side — PDF selected (2px `accent`, fill
`accent-100`, `file-type-2` icon) and Markdown (`file-code-2`). Options: `Paper size` segmented
(A4 / Letter), `Include canvas drawings` switch on, `Include the whole section` switch off. An
`accent-2-100` info strip noting the bundled Noto fonts. Footer: `Cancel` text button + `Export
PDF` primary pill.

### 2j — Empty & first run (three 520 × 560 frames)

1. **No notebooks**: 96px `accent-200` medallion with `book-open` 40px `accent-700`; "Start your
   first notebook" Caprasimo 28; explanation of the notebook → section → page model; two h46
   pills — `Create a notebook`, `Import from Markdown`.
2. **Empty section**: breadcrumb tags, "Nothing in this section yet" Caprasimo 28, then three
   16px-radius option rows on `neutral-100` with 40px circular icons — Blank page, Dictate a
   note, Photograph a page (OCR).
3. **Empty page**: "Untitled page" in Caprasimo 28 `neutral-400`, a 26px accent `+` beside "Type,
   or press / for blocks", and a dashed-topped `TRY ONE` row of four block chips.

### 2k — Mobile (390 × 844, iOS and Android)

Full editor parity. Six screens: Home, Notebook, Editor, Insert sheet, Ask sheet, Search.

- **Frame**: 40px corner radius, `bg` ground, 50px status strip.
- **Tab bar**: 84px tall, `surface`, 1px top divider, five slots — Home, Notebooks, centre FAB,
  Ask, Settings. Icons 22px; labels Figtree 10.5, 600 (700 + `accent-700` when active). The FAB
  is a 54px `accent` circle with `shadow-md`, raised 6px.
- **Home**: greeting Caprasimo 30 over two lines, 44px avatar, h48 search pill, `JUMP BACK IN`
  cards (radius 22), `NOTEBOOKS` two-up grid.
- **Notebook**: back button 44px, notebook switcher pill, accordion sections, 56px page rows
  radius 20 (selected `accent-200`), a dashed `New section` pill.
- **Editor**: page on a `neutral-100` card radius 28, inset 12px. Bottom bar: 52px accent FAB
  (`+`) | a 52px pill holding B / I / lists / draw / mic as 44px targets | a 52px `accent-2-500`
  circle for Ask.
- **Insert sheet**: bottom sheet on `surface`, radius `36 36 40 40`, grab handle, title
  Caprasimo 22, a 3 × 3 grid of 20px-radius tiles (22px `accent-600` icon over Figtree 12.5/600
  label), and a `Close` pill. Page behind at 35% opacity.
- **Ask sheet**: full-height, same segmented control and bubble geometry as 2d, scaled up —
  bubbles 14.5px, composer h52, send 40px.
- **Search**: focused input with a 1.5px `accent` border and a `Cancel` link; grouped results as
  20px-radius cards; actions rows 56px, the AI action on `accent-100`.

---

## Interactions & behaviour

- **Notebook switching** — tapping the sidebar switcher opens a popover list of notebooks
  (colour dot + name + page count) plus `New notebook`. Replaces `NotebookRail`.
- **Section expand/collapse** — chevron rotates −90° collapsed, 160ms ease-out, matching the
  current `AnimatedRotation` / `AnimatedCrossFade` timings.
- **Row actions** — the `…` appears on hover (always visible on the selected row and on mobile)
  and opens the same menus the code already has: Rename / recolor / Delete for notebooks and
  sections; Rename / Export as Markdown / Export as PDF / Delete for pages.
- **Insert tray** — opens from the format bar `Insert`, from the `+` in the empty-line gutter,
  from `/`, and from the mobile FAB. Selecting a chip inserts the block at the caret and closes
  the tray. Same nine block types the toolbar exposes today.
- **Ask composer** — typing and submitting opens the 400px dock with the turn already in it.
  `/` in the composer offers summarise, quiz, check writing (today's `/ask` and `/summary`
  slash commands).
- **Save state** — the status line replaces the bottom-right `_StatusBar`: `Edited` while dirty,
  `Saving…` during the 2s-debounced write, `All changes saved · edited <relative>` after, and
  an error state in `error` colour. Pending image syncs append "· N images not synced".
- **Search** — ⌘K / Ctrl+Shift+F opens the palette; ↑↓ moves, ↵ opens, ⌘↵ opens in split; Esc
  closes.
- **Responsive** — below 1100px the sidebar collapses to an overlay drawer behind a hamburger;
  below 720px switch to the mobile layout wholesale. The current width-based breakpoints in
  `toolbar.dart` (360 / 420 / 480 / 560 / 640) are no longer needed: the top bar keeps mark,
  search and `Ask Mario`, and everything else moves into the `…`.
- **Reduce motion** — the Appearance setting disables tray, panel and chevron animations.

## State

No new state model. The redesign reuses the existing providers:
`selectionProvider` (notebookId / sectionId / pageId), `notebooksStreamProvider`,
`sectionsStreamProvider`, `pagesStreamProvider`, `aiPanelProvider` (`isOpen`, `tab`),
`askSessionProvider`, `quizSessionProvider`, `settingsProvider`, `authStateProvider`.

New local state only:
- `pinnedPageIds` — a per-user list, persisted with the other `shared_preferences` settings.
- `insertTrayOpen` — editor-local bool.
- `paletteOpen` — replaces the `showGlobalSearch` dialog.
- `reduceMotion` — new field on the settings model.

`MarioThemeMode` loses its `book` case (or keeps it aliased to light).

## Assets

- `assets/mario_mark.png` — the current mark, 1024 × 1024. Used directly in the UI at 38 / 64 /
  24px. It is also the source of the entire palette. Ship it as the app icon.
- `mario_logo.svg` — the previous mark, kept for reference only; it is superseded.
- Fonts: Caprasimo and Figtree, both Google Fonts. The bundled Noto family under `assets/fonts/`
  stays as-is for PDF export.
- Icons: Lucide, stroke-width 2.75. No custom icons are introduced.
- No photography is used. If marketing imagery is added later, Organic wants it desaturated and
  lifted (`saturate(0.6) contrast(0.85) brightness(1.1) opacity(0.94)`) with rounded edges.

## Files

| File | What it is |
|---|---|
| `Mario Redesign.dc.html` | The new design, screens `2a`–`2k` |
| `Mario Today.dc.html` | Recreation of the current UI, screens `1a`–`1f` |
| `styles.css` | The Organic token sheet and component layer the redesign is built on |
| `assets/mario_mark.png` | The app mark, and the source of the palette |
| `mario_logo.svg` | Previous mark, superseded |

Source files the recreation was built from, for cross-reference:
`lib/ui/colors.dart`, `lib/ui/theme.dart`, `lib/app.dart`,
`lib/features/shell/{shell_screen,notebook_rail,nav_tree,toolbar}.dart`,
`lib/features/editor/{editor_screen,canvas_toolbar}.dart`,
`lib/features/ai/ai_side_panel.dart`, `lib/features/auth/login_screen.dart`,
`lib/features/settings/settings_screen.dart`, `lib/features/search/global_search.dart`,
`lib/features/sharing/share_dialog.dart`.
